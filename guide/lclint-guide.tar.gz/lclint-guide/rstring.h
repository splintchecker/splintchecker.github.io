typedef /*@abstract@*/ /*@refcounted@*/ struct {
   /*@refs@*/ int refs;
   char *contents;
} *rstring;


