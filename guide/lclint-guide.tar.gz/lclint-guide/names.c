char *stringreverse (char *s);

int f (int x)
{
  int lookalike = 1;
  int looka1ike = 2;

  if (x > 3)
    {
      int x = lookalike;
      x += looka1ike;
    }

  return x;
}
