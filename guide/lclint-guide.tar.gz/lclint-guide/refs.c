
typedef /*@abstract@*/ /*@refcounted@*/ struct {
   int refs;
   char *contents;
} *rstring;


