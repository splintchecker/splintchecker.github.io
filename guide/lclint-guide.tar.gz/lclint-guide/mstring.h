typedef /*@abstract@*/ char *mstring; 
 
