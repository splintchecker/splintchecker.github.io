#if !defined(BOOL_H)
#define BOOL_H
#define FALSE 0
#define TRUE (! FALSE)
typedef int bool;
#define bool_initMod()
#endif
