/*
** aliasChecks.h
**
** renamed to transferChecks.h
*/

# error "Obsolete header file used."
