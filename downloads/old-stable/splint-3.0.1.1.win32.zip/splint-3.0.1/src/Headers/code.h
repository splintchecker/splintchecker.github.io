/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
**
*/

/*@constant ltokenCode LEOFTOKEN;@*/
#define LEOFTOKEN 0

/* assume this is big enough for bison */ /* BOGUS! */
/*@constant ltokenCode NOTTOKEN;@*/
#define NOTTOKEN 9998
