# ifndef SIGNATURE2_H
# define SIGNATURE2_H

# include "signature_gen.h"

# else
# error "Multiple includes"
# endif
