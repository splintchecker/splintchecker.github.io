/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
**
*/
/*
** cvar.h
*/

# ifndef CVAR_H
# define CVAR_H

# else
# error "Multiple include"
# endif
