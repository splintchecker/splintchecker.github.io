/* herald.h - created automatically from herald.os2 and Makefile.os2 */
/*@constant observer char *LCL_VERSION;@*/
# define LCL_VERSION "LCLint 3.0.0.16 --- Sep 25 2001"
/*@constant observer char *LCL_PARSE_VERSION;@*/
# define LCL_PARSE_VERSION "LCLint 3.0.0.16"
/*@constant observer char *LCL_COMPILE;@*/
# define LCL_COMPILE "Compiled using icc -q -W2 -Dunlink=unlink -O+ -G5 -Gf+ -Gi+ -Gs+ \n on OS/2 Tue Sep 25 16:55:42 CET 2001 i586 by herbert,\n OS/2 specific subversion is 2"
