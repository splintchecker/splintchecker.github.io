/* local_constants.h - created automatically by gmake localconstants */
/*@constant observer char *DEFAULT_CPPCMD;@*/
# define DEFAULT_CPPCMD "cpp "
/*@constant observer char *SYSTEM_LIBDIR;@*/
# define SYSTEM_LIBDIR "\\usr\\include"
/*@constant observer char *DEFAULT_LARCHPATH;@*/
# define DEFAULT_LARCHPATH ".;\\usr\\lib\\lclint\\lib"
/*@constant observer char *DEFAULT_LCLIMPORTDIR;@*/
# define DEFAULT_LCLIMPORTDIR "\\usr\\lib\\lclint\\imports"
