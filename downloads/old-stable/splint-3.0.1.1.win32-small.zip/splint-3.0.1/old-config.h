/* config.h.  Generated automatically by configure.  */
/* config.hin.  Generated automatically from configure.ac by autoheader.  */

/*@-constmacros@*/

/* The directory where Splint's library files live */
#define DEFAULT_LARCHPATH ".:/usr/local/share/splint/lib:/af10/evans/LCLintDev/lib:"

/* Splint's imports directory */
#define DEFAULT_LCLIMPORTDIR ".:/usr/local/share/splint/imports:/af10/evans/LCLintDev/imports"

/* gcc's private include directory */
#define GCC_INCLUDE_DIR "/usr/lib/gcc-lib/i386-linux/2.7.2.1/include"

/* the system's main include directory */
#define GCC_INCLUDE_DIR2 "/usr/local/include"

/* String describing who compiled this binary and how */
#define LCL_COMPILE "Compiled using gcc -g -O2 on Linux paisley 2.4.9-12 #1 Tue Oct 30 18:33:49 EST 2001 i686 unknown by evans"

/* Splint's version number */
#define LCL_PARSE_VERSION "Splint 3.0.0.20"

/* Define to disable support LCL files */
/* #undef NOLCL */

/* Splint's version number and release date */
#define SPLINT_VERSION "Splint 3.0.0.20 --- 29 December 2001"

/* The system's main include directory */
#define SYSTEM_LIBDIR "/usr/local/include"

/* Define if you're on a Unixy system */
#define UNIX 1

/* Define if `lex' declares `yytext' as a `char *' by default, not a `char[]'.
   */
#define YYTEXT_POINTER 1

/*@=constmacros@*/
