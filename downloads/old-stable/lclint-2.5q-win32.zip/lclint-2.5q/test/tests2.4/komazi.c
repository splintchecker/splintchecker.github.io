void func(void)
{
	goto End;
End:
}
