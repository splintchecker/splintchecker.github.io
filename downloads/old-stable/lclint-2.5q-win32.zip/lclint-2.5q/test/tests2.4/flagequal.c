int f (void) {
  /*@-type@*/
  int x1 = 'a';
  /*@=type@*/
  int x2 = 'b';
}
    
