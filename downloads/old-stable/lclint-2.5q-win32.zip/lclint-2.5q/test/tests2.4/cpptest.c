int test (void) {
  int x = __P('a');

  return x;
}
  
