#include <dstdioasdf.h>
/* #include <malloc.h> */

main()
{
  int *p = (int *)malloc(sizeof(int)); 
  int *j;
  *j = 1;
  printf("Hello");
}
