# if 0
# error print this
# endif

int x = 'a';
