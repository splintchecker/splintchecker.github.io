enum {
      SCM_RIGHTS = 0x01,		/* Transfer file descriptors.  */
      SCM_ASD = 3.42,
    __SCM_CONNECT = "asdf"	/* Data array is `struct scm_connect'.  */
};

__extension__ typedef long long int quad_t;

typedef struct
{
  int val[2];
} fsid_t;				 

