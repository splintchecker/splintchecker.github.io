int main () {
  int i = 1;
  int j;

  switch (i) {
  case 1:
    j = 2;
  case 2:

  }

  printf ("j = %d", j);
}
  
