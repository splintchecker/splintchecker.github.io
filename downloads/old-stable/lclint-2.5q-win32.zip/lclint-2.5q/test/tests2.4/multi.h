#ifndef _multi_h 
#define _multi_h

#include "himom.h"
#include <stdio.h>

typedef struct Seq_uvar Seq_uvar;
typedef struct Seq_rvar Seq_rvar;

struct Seq_uvar
{
	Number_data			number;
};


struct Seq_rvar
{
	Planseq_list		planseq[MAX_PLANSEQ];
	int					num_plan;
	int					temp_num_plan;
	int					update_window;
	int					cyclet;
	int					sendin_flag;
	int					sendin_index;
	int					adapt_rule_flag;
	long int			plan_progt;
	long int			last_send;
};

#endif    /* _multi_h */
