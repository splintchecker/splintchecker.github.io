extern int test ();

# define test() (3)
