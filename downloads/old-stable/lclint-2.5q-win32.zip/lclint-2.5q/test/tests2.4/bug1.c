int main( void )
{
  int a=5,c=1;
  
  switch(a)
    {
    case 1:
      while (c>3)
	{
	case 3:
	  ++c;
	}
    }     
  
  return 7;
}
