# include "sys/types.h"

dev_t x = 3;
