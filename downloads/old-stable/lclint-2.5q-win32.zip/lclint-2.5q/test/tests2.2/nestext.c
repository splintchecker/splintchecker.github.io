int f (void)
{
  extern int test (void);

  return test();
}
