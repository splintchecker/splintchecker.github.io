extern void __eprintf (const char *, const char *, unsigned, const char *)
    __attribute__ ((noreturn));
