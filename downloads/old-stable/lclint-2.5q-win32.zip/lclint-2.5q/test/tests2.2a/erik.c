int main (void)
{
   float f;
   double d;

   scanf("%lf %f",&d, &f);
   
   return 0;
}
