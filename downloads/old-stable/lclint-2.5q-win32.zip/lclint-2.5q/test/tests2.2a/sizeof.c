size_t f (int x)
{
  return sizeof (sizeof (x));
}
