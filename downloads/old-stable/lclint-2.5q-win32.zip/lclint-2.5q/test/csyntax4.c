/* has parse errors in gcc */
typedef char *cstring;
typedef char *filename;

int f(cstring filename, int x); 

cstring filename;





