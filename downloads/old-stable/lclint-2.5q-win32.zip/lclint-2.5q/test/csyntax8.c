int x;

char y;
short int z;
int short w;

int f(int x, int y);

