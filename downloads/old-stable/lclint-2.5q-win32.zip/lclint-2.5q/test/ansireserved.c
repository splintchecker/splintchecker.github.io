int decimal_point;
int srand;
int labs;
int _x;
int atan2f (void);

typedef int wcst;

# define EVANS 72

int isaFish (void)
{
  /*@unused@*/ int powl;
  /*@unused@*/ float mem; /* okay */
  /*@unused@*/ float memory;
  /*@unused@*/ int wctomb;

  return 3;
}
  
