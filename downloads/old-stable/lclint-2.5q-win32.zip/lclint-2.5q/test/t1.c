void f ()
{
  int *z;
  z = (int *) malloc (4);
}



