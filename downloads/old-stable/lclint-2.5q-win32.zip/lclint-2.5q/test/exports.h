typedef int myint;

extern int glob;

extern int f(int a, int b);
