# include "minc1.h"
# include "minc2.h"
# include "minc3.h"
