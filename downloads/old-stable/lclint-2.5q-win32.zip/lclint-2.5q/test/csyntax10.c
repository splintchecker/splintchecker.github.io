typedef int tint;

int ffunc(tint tint)
{
  tint = 3;
  return tint;
}

int gfunc()
{
  tint tint;

  tint = 3;
  return tint;
}

struct x
{
  tint tint;
} ;
