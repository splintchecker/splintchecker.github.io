int mod (int p[])
{
  (void) f1 (p); /* 6. Statement has no effect: (void)f1(p) */
  (void) f2 (p);

  return 5;
}
