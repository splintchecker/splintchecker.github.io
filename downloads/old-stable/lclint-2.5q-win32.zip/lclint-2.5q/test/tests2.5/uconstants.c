void f (void) {
  unsigned int x0 = 0x9423U;
  unsigned long int x1 = 0x9423UL;

}
