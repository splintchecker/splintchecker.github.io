typedef char *cstring;
extern cstring add_extension(cstring s, const cstring suffix, cstring cstring);
