int x = 'c';

/*@-linelen 25@*/

int y = 'c';

/*@+linelen 13@*/
/*@+internalnamelen 2@*/

int xx1;
int xx2;

/*@=linelen 25@*/
/*@-linelen 70@*/
/*@-dump asdf@*/
/*@-macrovarprefix@*/
/*@-macrovarprefix    @*/
/*@-linelen asdf@*/
