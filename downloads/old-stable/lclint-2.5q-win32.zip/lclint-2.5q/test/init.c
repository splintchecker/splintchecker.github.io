char c[][] = { NULL, "hullo", { 'a', 'b', 3 }, NULL };

struct { char *name; int x[]; char *uname; int y; } st 
  = { "bob", { 1, 2}, NULL, 1.2 }; 

struct { char *name; int x[]; char *uname; int y; } st2[] 
  = { { "bob", { 1, 2}, NULL }, 
      { "charly", 3, NULL, 4 } } ;

int a[10] = { 1, 2, 3, 4, 3.4, 6, 4 } ;

int aa[][] = { { 1, 2, 3} , { 1, 3.2, 3} };

int b[10] = { { 1, 2} , {3, 4} } ;


