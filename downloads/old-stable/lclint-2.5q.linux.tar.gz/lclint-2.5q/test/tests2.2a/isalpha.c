# include "../bool.h"

bool f (char c)
{
  return isalpha (c);
}
