/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
**
*/

extern void processImport (lsymbol p_importSymbol, ltoken p_tok, impkind p_kind);
extern void outputLCSFile (char *p_path, char *p_msg, char *p_specname);
extern void importCTrait (void);
