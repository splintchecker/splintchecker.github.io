/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
*/

typedef struct {
  bool isObj;
  lclTypeSpecNode type;
  abstDeclaratorNode abst;
} *typeNamePack;

