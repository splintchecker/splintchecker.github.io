# ifndef DBASE_H
# define DBASE_H

# include "eref.h"
# include "erc.h"

# include "dbase.lh"

# endif
