int f (void) {
  unsigned int m1 = 0xFF;
  unsigned int m2 = 0142;

  return m1 + m2;
}
