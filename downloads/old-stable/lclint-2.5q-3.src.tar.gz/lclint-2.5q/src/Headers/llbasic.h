/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2000.
** See ../LICENSE for license information.
**
*/

# ifndef LLBASIC_H
# define LLBASIC_H

# include "basic.h"

# ifndef NOLCL
# include "llglobals.h"
# endif

# else
# error "Multiple include"
# endif





