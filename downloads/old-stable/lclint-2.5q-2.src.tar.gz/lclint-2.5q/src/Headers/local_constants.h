/* local_constants.h - created automatically by gmake localconstants */
/*@constant observer char *SYSTEM_LIBDIR;@*/
# define SYSTEM_LIBDIR "/usr/include"
/*@constant observer char *DEFAULT_LARCHPATH;@*/
# define DEFAULT_LARCHPATH ".:/a/apollo.cs.Virginia.EDU/af10/evans/lclint-build/lclint-2.5m/lib"
/*@constant observer char *DEFAULT_LCLIMPORTDIR;@*/
# define DEFAULT_LCLIMPORTDIR "/a/apollo.cs.Virginia.EDU/af10/evans/lclint-build/lclint-2.5m/imports"
