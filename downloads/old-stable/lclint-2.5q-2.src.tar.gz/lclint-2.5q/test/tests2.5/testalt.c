int /*@alt void@*/ test1 (...);
int /*@alt void@*/ test2 (...);
