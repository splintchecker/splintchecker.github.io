typedef unsigned S;
typedef struct {
  unsigned u: ((S) 4);
} T;
