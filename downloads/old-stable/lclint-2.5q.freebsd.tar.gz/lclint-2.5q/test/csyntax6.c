int f(char *, int);
