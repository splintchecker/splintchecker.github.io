typedef int *mut;

# include "mut.lh"
