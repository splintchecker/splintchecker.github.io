int main (void) {
  int  *ip;
  *ip = 3;           /* 5. possible null deref */
}
