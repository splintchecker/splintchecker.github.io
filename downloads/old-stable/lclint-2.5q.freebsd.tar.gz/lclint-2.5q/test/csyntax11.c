typedef enum { eone } one;

typedef struct
{
  int x;
  one onet;
} emp;
