
typedef struct _CTypesNode {
  bits intfield;  
  sort sort;
  ltokenList ctypes;
} *CTypesNode;

