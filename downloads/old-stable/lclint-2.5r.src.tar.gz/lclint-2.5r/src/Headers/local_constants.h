/* local_constants.h - created automatically by gmake localconstants */
/*@constant observer char *SYSTEM_LIBDIR;@*/
# define SYSTEM_LIBDIR "/usr/include"
/*@constant observer char *DEFAULT_LARCHPATH;@*/
# define DEFAULT_LARCHPATH ".:/af10/evans/lclint-2.5q/lib"
/*@constant observer char *DEFAULT_LCLIMPORTDIR;@*/
# define DEFAULT_LCLIMPORTDIR "/af10/evans/lclint-2.5q/imports"
