typedef int a1;

a1 main()
{
  int x;
  a1 a1;
  
  x = 3;
  a1 = x;
  return a1;
}

