typedef enum { FALSE, TRUE } bool;
