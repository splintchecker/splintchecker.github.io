/* herald.h - created automatically by gmake updateversion */
/*@constant observer char *LCL_VERSION;@*/
# define LCL_VERSION "LCLint 2.5m --- 20 May 2000"
/*@constant observer char *LCL_PARSE_VERSION;@*/
# define LCL_PARSE_VERSION "LCLint 2.5m"
/*@constant observer char *LCL_COMPILE;@*/
# define LCL_COMPILE "Compiled using gcc -DSTDC_HEADERS=1 on FreeBSD shankly.cs.virginia.edu 3.2-RELEASE FreeBSD 3.2-RELEASE #0: Tue May 18 04:05:08 GMT 1999 jkh@cathair:/usr/src/sys/compile/GENERIC i386 by evans"
