/* ereftab.h  */

# ifndef EREFTAB_H
# define EREFTAB_H

# include "erc.h"
# include "eref.h"

typedef erc ereftab;

# include "ereftab.lh"
# endif

