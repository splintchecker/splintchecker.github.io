typedef /*@abstract@*/ int pivo;
