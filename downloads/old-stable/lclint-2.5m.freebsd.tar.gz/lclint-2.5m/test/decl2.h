extern int glob;
extern int glob;
extern int glob2[];
extern int glob3;
