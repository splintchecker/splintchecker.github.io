/*
** aliasChecks.c has been renamed transferChecks.c. 
*/

# error "Obsolete file compiled."
