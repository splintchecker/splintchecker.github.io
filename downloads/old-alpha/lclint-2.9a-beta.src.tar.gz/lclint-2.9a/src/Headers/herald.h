/* herald.h - created automatically by gmake updateversion */
/*@constant observer char *LCL_VERSION;@*/
# define LCL_VERSION "LCLint 2.9a --- 6 April 2001"
/*@constant observer char *LCL_PARSE_VERSION;@*/
# define LCL_PARSE_VERSION "LCLint 2.9a"
/*@constant observer char *LCL_COMPILE;@*/
# define LCL_COMPILE "Compiled using gcc -g -Wall -Wfloat-equal -Wtraditional -Wshadow -Wpointer-arith -Wcast-qual -Wcast-align -Wwrite-strings -Wconversion -Wsign-compare -Wstrict-prototypes -Wmissing-format-attribute -Wformat -Wredundant-decls -Wunreachable-code  on Linux fowler.cs.Virginia.EDU 2.4.0-test9 #2 SMP Thu Oct 26 09:55:17 EDT 2000 i686 unknown by evans"
