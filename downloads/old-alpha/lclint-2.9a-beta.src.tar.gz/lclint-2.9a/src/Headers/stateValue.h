/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
*/
/*
** stateValue.h
*/

# ifndef STATEVALUE_H
# define STATEVALUE_H

/*
** Keeps track of the value of a state variable, as well as tracking
** information about its history.
*/

struct _stateValue
{
  int value;
  /*@only@*/ stateInfo info;
};

extern stateValue stateValue_create (int p_value, /*@only@*/ stateInfo p_info) /*@*/ ;

extern /*@truenull@*/ bool stateValue_isUndefined (stateValue) /*@*/ ;
# define stateValue_isUndefined(p_s) ((p_s) == NULL)

extern /*@falsenull@*/ bool stateValue_isDefined (stateValue) /*@*/ ;
# define stateValue_isDefined(p_s) ((p_s) != NULL)

extern int stateValue_getValue (stateValue p_s) /*@*/ ;
# define stateValue_getValue(p_s) ((p_s)->value)

extern void stateValue_update (stateValue p_res, stateValue p_val) /*@modifies p_res@*/ ;

extern /*@observer@*/ stateInfo stateValue_getInfo (stateValue p_s) /*@*/ ;
# define stateValue_getInfo(p_s) ((p_s)->info)

extern void stateValue_updateValue (/*@sef@*/ stateValue p_s, int p_value, /*@only@*/ stateInfo p_info) /*@modifies p_s@*/ ;

extern void stateValue_updateValueLoc (stateValue p_s, int p_value, fileloc p_loc) /*@modifies p_s@*/ ;

extern void stateValue_show (stateValue p_s, metaStateInfo p_msinfo) ;

extern stateValue stateValue_copy (stateValue p_s) /*@*/ ;

extern /*@observer@*/ cstring 
   stateValue_unparseValue (stateValue p_s, metaStateInfo p_msinfo) /*@*/ ;

extern cstring stateValue_unparse (stateValue p_s) /*@*/ ;

extern bool stateValue_isError (stateValue p_s) /*@*/ ;
# define stateValue_isError(p_s) ((p_s)->value == stateValue_error)

/*@constant int stateValue_error@*/ 
# define stateValue_error -1

# else
# error "Multiple include"
# endif
