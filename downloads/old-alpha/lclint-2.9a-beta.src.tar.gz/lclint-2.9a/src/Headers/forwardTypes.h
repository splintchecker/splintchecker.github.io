# ifndef FORWARDTYPES_H
# define FORWARDTYPES_H

# ifndef NOLCL
# include "lclForwardTypes.h"
# endif

abst_typedef /*@null@*/ struct _sRef *sRef;
abst_typedef /*@null@*/ struct _uentry *uentry;
immut_typedef int typeIdSet;
typedef /*@only@*/ uentry o_uentry;
abst_typedef struct _mttok *mttok;
abst_typedef /*@null@*/ struct _idDecl *idDecl;
abst_typedef /*@null@*/ struct _usymtab  *usymtab;
abst_typedef /*@null@*/ struct _exprNode *exprNode;
abst_typedef /*@null@*/ struct _guardSet *guardSet;
abst_typedef /*@null@*/ struct _sRefSet *sRefSet;
abst_typedef /*@null@*/ struct _sRefList *sRefList ;
abst_typedef /*@null@*/ struct _aliasTable *aliasTable;
abst_typedef /*@null@*/ struct __fileloc *fileloc;
abst_typedef /*@null@*/ struct _cstringTable *cstringTable;
abst_typedef /*@null@*/ struct _genericTable *genericTable;
abst_typedef /*@null@*/ struct _annotationInfo *annotationInfo;
abst_typedef /*@null@*/ struct _inputStream *inputStream;
abst_typedef struct _stateValue *stateValue;
abst_typedef /*@null@*/ genericTable valueTable;
abst_typedef /*@null@*/ genericTable metaStateTable;
abst_typedef /*@null@*/ genericTable annotationTable;
abst_typedef /*@null@*/ struct _metaStateInfo *metaStateInfo;

abst_typedef /*@null@*/ struct _functionClause *functionClause;
abst_typedef /*@null@*/ struct _functionClauseList *functionClauseList;

abst_typedef struct _globalsClause *globalsClause;
abst_typedef struct _modifiesClause *modifiesClause;
abst_typedef /*@null@*/ struct _warnClause *warnClause;
abst_typedef struct _stateClause *stateClause;

abst_typedef /*@null@*/ struct _stateClauseList *stateClauseList;

/* The mt grammar nodes: */
abst_typedef struct _mtDeclarationNode *mtDeclarationNode;
abst_typedef /*@null@*/ struct _mtDeclarationPiece *mtDeclarationPiece;
abst_typedef /*@null@*/ struct _mtDeclarationPieces *mtDeclarationPieces;
abst_typedef struct _mtContextNode *mtContextNode;
abst_typedef struct _mtValuesNode *mtValuesNode;
abst_typedef struct _mtDefaultsNode *mtDefaultsNode;
abst_typedef /*@null@*/ struct _mtDefaultsDeclList *mtDefaultsDeclList;
abst_typedef struct _mtDefaultsDecl *mtDefaultsDecl;
abst_typedef struct _mtAnnotationsNode *mtAnnotationsNode;
abst_typedef /*@null@*/ struct _mtAnnotationList *mtAnnotationList;
abst_typedef struct _mtAnnotationDecl *mtAnnotationDecl;
abst_typedef struct _mtMergeNode *mtMergeNode;
abst_typedef struct _mtMergeItem *mtMergeItem;
abst_typedef /*@null@*/ struct _mtMergeClauseList *mtMergeClauseList;
abst_typedef struct _mtMergeClause *mtMergeClause;
abst_typedef /*@null@*/ struct _mtTransferClauseList *mtTransferClauseList;
abst_typedef struct _mtTransferClause *mtTransferClause;
abst_typedef /*@null@*/ struct _mtLoseReferenceList *mtLoseReferenceList;
abst_typedef struct _mtLoseReference *mtLoseReference;
abst_typedef struct _mtTransferAction *mtTransferAction;
abst_typedef sRefSet globSet;

/*@-cppnames@*/
typedef int bool;
/*@=cppnames@*/

abst_typedef /*@null@*/ char *cstring;
typedef /*@only@*/ cstring o_cstring;

immut_typedef int ctype;

/* sRef -> bool */
typedef bool (*sRefTest) (sRef);

/* sRef, fileloc -> void; modifies sRef */
typedef void (*sRefMod) (sRef, fileloc);

/* sRef, int, fileloc -> void; modifies sRef */
typedef void (*sRefModVal) (sRef, int, fileloc);

/* sRef -> void */
typedef void (*sRefShower) (sRef);

# else
# error "Multiple include"
# endif




