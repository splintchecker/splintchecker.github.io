/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
**
*/
/*
** warnClause.h
*/

# ifndef WARNCLAUSE_H
# define WARNCLAUSE_H
  
struct _warnClause
{
  /*@only@*/ fileloc loc;
  /*@only@*/ cstring flagname;
  /*@only@*/ exprNode msg;
} ;

/*@constant null warnClause warnClause_undefined; @*/
# define warnClause_undefined    ((warnClause) NULL)

extern /*@falsenull@*/ bool warnClause_isDefined (/*@null@*/ warnClause p_f) /*@*/ ;
extern /*@truenull@*/ bool warnClause_isUndefined (/*@null@*/ warnClause p_f) /*@*/ ;

# define warnClause_isDefined(f)   ((f) != warnClause_undefined)
# define warnClause_isUndefined(f) ((f) == warnClause_undefined)

extern warnClause warnClause_create (/*@only@*/ lltok,
				     /*@only@*/ cstring p_flagname,
				     /*@only@*/ exprNode p_msg) /*@*/ ;

extern /*@observer@*/ cstring warnClause_getMessage (warnClause p_w) /*@*/ ;
extern /*@only@*/ cstring warnClause_unparse (warnClause p_w) /*@*/ ;

extern void warnClause_free (/*@only@*/ warnClause p_w);

# else
# error "Multiple include"
# endif













