/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
*/
/*
** annotationInfo.h
**
** A record that keeps information on a user-defined annotations including:
**
*/

# ifndef ANNOTINFO_H
# define ANNOTINFO_H

struct _annotationInfo {
  /*@dependent@*/ /*@observer@*/ metaStateInfo state;
  /* associated metaStateInfo entry */
  fileloc loc;
  int value;
  /* context */
} ;

/* typedef struct _annotationInfo *annotationInfo; */

/*@constant null annotationInfo annotationInfo_undefined; @*/
# define annotationInfo_undefined    ((annotationInfo) NULL)

extern /*@falsenull@*/ bool annotationInfo_isDefined (annotationInfo) /*@*/ ;
# define annotationInfo_isDefined(p_info) ((p_info) != NULL)

extern bool annotationInfo_equal (annotationInfo, annotationInfo) /*@*/ ;
# define annotationInfo_equal(p_info1, p_info2) ((p_info1) == (p_info2))

extern /*@observer@*/ metaStateInfo annotationInfo_getState (annotationInfo) /*@*/ ;
extern int annotationInfo_getValue (annotationInfo) /*@*/ ;

extern /*@only@*/ annotationInfo annotationInfo_create (/*@dependent@*/ /*@exposed@*/ metaStateInfo p_state, int p_value, /*@only@*/ fileloc p_loc) /*@*/ ;
extern /*@observer@*/ cstring annotationInfo_unparse (annotationInfo p_ainfo);

extern /*@observer@*/ fileloc annotationInfo_getLoc (annotationInfo p_ainfo) /*@*/ ;

extern void annotationInfo_free (/*@only@*/ annotationInfo) ;

# else
# error "Multiple include"
# endif 




