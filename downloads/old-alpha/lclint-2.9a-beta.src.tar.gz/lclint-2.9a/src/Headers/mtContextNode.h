/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
**
*/
/*
** mtContextNode.h
*/

# ifndef MTCONTEXTNODE_H
# define MTCONTEXTNODE_H

struct _mtContextNode {
  enum __mtContext { MTC_PARAM, MTC_REFERENCE, MTC_CLAUSE } context;
} ;

extern mtContextNode mtContextNode_createParameter (void) /*@*/ ;
extern mtContextNode mtContextNode_createReference (void) /*@*/ ;
extern mtContextNode mtContextNode_createClause (void) /*@*/ ;

extern cstring mtContextNode_unparse (mtContextNode p_node) /*@*/ ;
extern void mtContextNode_free (/*@only@*/ mtContextNode) ;

extern bool mtContextNode_isRef (mtContextNode) /*@*/;
# define mtContextNode_isRef(n) ((n)->context == MTC_REFERENCE)

extern bool mtContextNode_isParameter (mtContextNode) /*@*/;
# define mtContextNode_isParameter(n) ((n)->context == MTC_PARAM)

extern bool mtContextNode_isClause (mtContextNode) /*@*/;
# define mtContextNode_isClause(n) ((n)->context == MTC_CLAUSE)

# else
# error "Multiple include"
# endif
