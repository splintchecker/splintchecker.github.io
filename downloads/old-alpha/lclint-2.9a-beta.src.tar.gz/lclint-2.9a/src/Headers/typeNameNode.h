/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
*/

typedef struct _typeNameNode {
  bool isTypeName;
  /*@null@*/ typeNamePack typename;
  /*@null@*/ struct _opFormNode *opform;  
} *typeNameNode;

extern void typeNameNode_free (/*@only@*/ /*@null@*/ typeNameNode p_n);
extern /*@only@*/ cstring typeNameNode_unparse (/*@null@*/ typeNameNode p_n);
