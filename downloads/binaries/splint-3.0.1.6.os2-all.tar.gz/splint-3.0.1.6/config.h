/* config.h.  Generated automatically by configure.  */
/* config.hin.  Generated automatically from configure.ac by autoheader.  */

/*@-constmacros@*/

/* The directory where Splint's library files live */
#define DEFAULT_LARCHPATH ".;e:/usr/lib/splint/lib"

/* Splint's imports directory */
#define DEFAULT_LCLIMPORTDIR ".;e:/usr/lib/splint/imports"

/* system include directory */
#define GCC_INCLUDE_DIR "e:/usr/include"

/* alternate include directory */
#define GCC_INCLUDE_DIR2 "e:/emx/include"

#define TARGET_CPU "i586"
#define UNAME "OS/2 Warp 4 (Paulina)"

/* String describing who compiled this binary and how */
#define LCL_COMPILE "Compiled using icc -q -W2 -Dunlink=unlink -O+ -G5 -Gf+ -Gi+ -Gs+ \n on OS/2 Warp 4 (Paulina) i586 Sun Feb 17 22:25:03 CET 2002 by Herbert,\n OS/2 specific subversion is 1"

/* Splint's version number */
#define LCL_PARSE_VERSION "Splint 3.0.1.6"

/* Splint's version number and configure/build date */
#define SPLINT_VERSION "Splint 3.0.1.6 -- 17 Feb 2002"

/* The system's main include directory */
#define SYSTEM_LIBDIR "e:/usr/include"

/*@=constmacros@*/
