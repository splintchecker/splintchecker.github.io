int f (void)
{
  int x = 'a';
  double z = 3;

  x = x + 'c' + 2 + z;

  return 'a';
}

short s[] = { 0, -1 } ;
unsigned u = -3;
