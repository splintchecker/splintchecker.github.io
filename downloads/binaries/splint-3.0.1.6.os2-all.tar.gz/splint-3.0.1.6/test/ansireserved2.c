typedef struct _s1
{
  int x;
} s1;

