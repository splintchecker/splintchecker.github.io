# ifndef LCLMISC_H
# define LCLMISC_H

typedef	unsigned int bits;
typedef long unsigned Handle;

extern char *FormatInt (int p_i) /*@*/ ;
extern bool firstWord (char *p_s, char *p_w);

# endif
