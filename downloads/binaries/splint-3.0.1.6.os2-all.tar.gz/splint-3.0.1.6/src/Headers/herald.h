/* herald.h - created automatically by gmake updateversion */
/*@constant observer char *LCL_VERSION;@*/
# define LCL_VERSION "LCLint 3.0.0.18 --- 5 October 2001"
/*@constant observer char *LCL_PARSE_VERSION;@*/
# define LCL_PARSE_VERSION "LCLint 3.0.0.18"
/*@constant observer char *LCL_COMPILE;@*/
# define LCL_COMPILE "Compiled using gcc -DSTDC_HEADERS=1 -g on Linux matthews.cs.Virginia.EDU 2.4.3-12 #1 Fri Jun 8 13:35:30 EDT 2001 i686 unknown by drl7x"
