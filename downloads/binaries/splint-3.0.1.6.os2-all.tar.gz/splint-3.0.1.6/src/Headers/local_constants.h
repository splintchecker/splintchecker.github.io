/* local_constants.h - created automatically by gmake localconstants */
/*@constant observer char *SYSTEM_LIBDIR;@*/
# define SYSTEM_LIBDIR "/usr/include"
/*@constant observer char *DEFAULT_LARCHPATH;@*/
# define DEFAULT_LARCHPATH ".:/af9/drl7x/reTmp/LCLintDev/lib"
/*@constant observer char *DEFAULT_LCLIMPORTDIR;@*/
# define DEFAULT_LCLIMPORTDIR "/af9/drl7x/reTmp/LCLintDev/imports"
