typedef union {
  lltok ltok;  /* a leaf is also an ltoken */
} YYSTYPE;
#define	MT_STATE	257

