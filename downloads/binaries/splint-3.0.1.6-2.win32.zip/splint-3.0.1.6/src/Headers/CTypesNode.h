/*
** Copyright (C) University of Virginia, Massachusetts Institue of Technology 1994-2001.
** See ../LICENSE for license information.
**
*/

typedef struct {
  bits intfield;  
  sort sort;
  ltokenList ctypes;
} *CTypesNode;

