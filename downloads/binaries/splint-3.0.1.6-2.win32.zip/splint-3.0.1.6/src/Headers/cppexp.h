extern HOST_WIDE_INT cppReader_parseExpression (cppReader *);

