/*@constant observer char *SANITIZE_VERSION;@*/
# define SANITIZE_VERSION "Sanitizer 0.1+ --- Fri Dec 12 19:51:34 EST 1997"
/*@constant observer char *SANITIZE_COMPILE;@*/
# define SANITIZE_COMPILE "Compiled using gcc -O5  on Linux spd.lcs.mit.edu 2.0.32 #4 Sun Nov 16 22:17:18 EST 1997 i586 unknown by evs"
