void f (void)
{
  int x = 3 / 0;
  double d = 3.0 / 0.0;
  
}
