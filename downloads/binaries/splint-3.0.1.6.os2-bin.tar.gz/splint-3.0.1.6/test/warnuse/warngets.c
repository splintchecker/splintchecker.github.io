void wfunc (char *s)
{
  (void) gets (s);
}
