long octlong = 07L;
long hexlong = 0x34L;
long llong = 3594UL;
unsigned long ullong = 3594UL;
