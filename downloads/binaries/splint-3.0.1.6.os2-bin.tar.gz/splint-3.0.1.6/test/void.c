typedef void VOID;

int f (VOID)
{
  f();
  return 3;
}
