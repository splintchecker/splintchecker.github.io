# include "forward.h"

/*@-macrofcndecl@*/
# define mmash(x) ((x) + 3)
/*@=macrofcndecl@*/
