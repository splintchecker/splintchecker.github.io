void f (int x) {
  switch (x) {
  case 1:
  }

  switch (x) {
  default:
  }
}
