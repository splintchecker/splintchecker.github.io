void multiError(char * buf)
{
	buf[0] = 's';
	buf[2] =  's';
	buf[1] =  's';
}

