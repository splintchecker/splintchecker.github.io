typedef /*@abstract@*/ /*@mutable@*/ struct { 
   int r; int g; int b; 
} color;
