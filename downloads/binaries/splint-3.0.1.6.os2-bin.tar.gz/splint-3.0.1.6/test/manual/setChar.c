char buf[10];

void setChar()
{
   buf[10] = 'x';
}


