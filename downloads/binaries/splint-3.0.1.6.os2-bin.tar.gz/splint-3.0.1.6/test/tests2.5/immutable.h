typedef /*@abstract@*/ /*@immutable@*/ struct __ {
  int x;
} *immutable;

extern immutable immutable_create (int) ;
extern void immutable_print (immutable) ;
