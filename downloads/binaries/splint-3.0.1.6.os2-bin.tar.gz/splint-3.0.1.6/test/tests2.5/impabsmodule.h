/*module.h*/
typedef /*@abstract@*/long abst_T;
typedef long abst2_T;
int isTwo(void);

