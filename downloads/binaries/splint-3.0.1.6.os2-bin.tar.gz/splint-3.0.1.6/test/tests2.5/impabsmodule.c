/*
** Contributed by Linus Rydberg <linus.rydberg@space.se>
*/

#include "impabsmodule.h"
int isTwo(void)
{
  abst_T var;
  abst2_T var2;
  if (var==(abst_T)var2)
    return 1;
  else
    return 0;
}
