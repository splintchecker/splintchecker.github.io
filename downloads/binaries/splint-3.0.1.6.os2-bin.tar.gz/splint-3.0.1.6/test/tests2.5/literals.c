void test ()
{
  char a;
  unsigned int b;

  a = 15;
  b = 39;
  a = b;
}
