/*
 * baz.h
 */

#ifndef _BAZ_H_
#define _BAZ_H_

struct pxs {
  int a;
  int b;
  int c[4];
  int d;
};

typedef struct pxs pxt;

struct xstr {
  pxt a;
};

typedef struct xstr pvt;

struct pvas {
  int a;
  int b[4];
};

typedef struct pvas ppvat;

struct pvzas {
  int a;
  int c[4];
};

typedef struct pvzas pvzat;

struct p4zas {
  int a;
  int b[4];
};

struct yabbawabba {
  pxt  a;
};

#endif /* !_BAZ_H_ */


