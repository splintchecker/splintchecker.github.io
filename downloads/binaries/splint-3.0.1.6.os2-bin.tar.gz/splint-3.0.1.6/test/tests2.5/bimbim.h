/*
 * bimbim.h
 */

#ifndef _BIMBIM_H_
#define _BIMBIM_H_

#include <baz.h>

#endif /* !_BIMBIM_H_ */
