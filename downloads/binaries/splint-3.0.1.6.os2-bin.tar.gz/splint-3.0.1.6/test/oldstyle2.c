
void
oldDec(x)
     int x; 
{
  x = 5;
} 


void
noShadow()
{   
   switch (0)
	  {
	    int   x;
		  case 0:
		{  x = 0;}
        }
}   



void
unrecognized()
{   
   switch (0)
	  {
	  case 0:
		{  x = 0;}
        }
}   
