
char buf[8] = "\000\000\000\000\000\000\000\000";
char bufa[8] = "\000\000\000\000\000\000\000\001";
char buf2[4] = "abcd";
char buf3[4] = "ab\n";
char buf4[4] = "\034\342\24";
char buf5[4] = "abcdef";

