
/*@constant int MYSIZE=10@*/

void arrayExpr()
{
  char string1[2 + 4];

  char string2 [MYSIZE + 1];

  string1[5] = 'd';
  string2[MYSIZE - 1] = 'w';
 string2[MYSIZE] = 'w';
}
