void foo ()

{
  char *d;

  d = "df";

  bar(d);
}
