void fooSub (   char *s, int i)
{
  s[i] = 'd';
  s[i - 2] = 'd';
}

void fooAdd (   char *s, int i)
{
  s[i] = 'd';
  s[i + 2] = 'd';

}
