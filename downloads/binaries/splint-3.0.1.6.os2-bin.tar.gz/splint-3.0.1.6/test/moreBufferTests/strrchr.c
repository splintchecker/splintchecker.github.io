
void
bar (char * t)
{

  char *tt;
  tt = strrchr (t, '\n');
}


