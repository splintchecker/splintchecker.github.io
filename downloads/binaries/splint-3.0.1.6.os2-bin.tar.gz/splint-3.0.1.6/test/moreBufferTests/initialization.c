void initialization (char *d)
{
  char *e =  d;
  {
    char g = e[22];
    char *f = e;
  e[2] = 'd';
  f[2] = 'l';
  }
}

