void f()
{
int j, i;
char s[11];
char t[11];
for (j = 0; j <= 10; j++)
  {
    s[j] = '\0';
  }

for (i = 0; i <= 11; i++)
  {
    t[i] = '\0';
  }

}
