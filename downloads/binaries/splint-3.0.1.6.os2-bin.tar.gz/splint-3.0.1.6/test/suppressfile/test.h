int x = 2.5;
