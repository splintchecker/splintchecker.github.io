/*
struct st {
  int x;
} ;
*/

typedef struct st st;
