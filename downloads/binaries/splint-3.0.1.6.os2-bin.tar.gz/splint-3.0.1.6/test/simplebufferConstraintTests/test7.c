
void t(char *g, char *j )
{
  g++;
  g++;
  g[2] = 'l';
  g[0] = g[2];
  j[0] = 'l';
  j++;
  j++;
}
