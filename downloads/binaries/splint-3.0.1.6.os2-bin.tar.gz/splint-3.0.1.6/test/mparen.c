# define FOO 2+1

int fooey (int f)
{
  return (f * FOO);
}
