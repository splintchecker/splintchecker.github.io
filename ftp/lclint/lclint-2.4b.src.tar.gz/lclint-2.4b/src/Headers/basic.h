/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/

# ifndef BASIC_H
# define BASIC_H

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>
# include <float.h>
# include "general.h"
# include "ynm.h"
# include "message.h" 
# include "fileloc.h"
# include "globals.h"
# include "qual.h"
# include "lltok.h"
# include "clause.h"
# include "cstringSList.h"
# include "flag_codes.h"
# include "flags.h"
# include "llerror.h" 
# include "source.h"
# include "qualList.h"

# ifndef NOLCL
# include "code.h"
# include "mapping.h"
# include "sort.h"
# include "lclctypes.h"
# include "paramNode.h"
# include "paramNodeList.h"
# include "lsymbol.h"
# include "abstract.h"
# include "symtable.h"
# endif

# include "exprNodeList.h"
# include "cprim.h"
# include "hashTable.h"
# include "filelocList.h"
# include "enumNameList.h"
# include "enumNameSList.h"
# include "varKinds.h"
# include "sRefSet.h"
# include "ekind.h"
# include "usymIdSet.h"
# include "uentryList.h"
# include "globSet.h"
# include "ctypeList.h"
# include "aliasTable.h"
# include "usymtab.h"
# include "lctype.h"
# include "qtype.h"
# include "idDecl.h"
# include "multiVal.h"
# include "specialClauses.h"
# include "uentry.h"
# include "sRef.h"
# include "guardSet.h"
# include "exprNode.h"
# include "typeIdSet.h"
# include "idDeclList.h"
# include "clabstract.h"
# include "sRefSetList.h"
# include "flagMarker.h"
# include "flagMarkerList.h"
# include "macrocache.h"
# include "fileTable.h"
# include "messageLog.h"
# include "clauseStack.h"
# include "context.h"
# include "constants.h"
# include "local_constants.h"

# else
# error "Multiple include"
# endif

