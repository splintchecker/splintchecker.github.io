/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/       

# ifndef VARNODE_H
# define VARNODE_H

typedef struct _varNode { /* with sort, useful in quantified */
  ltoken varid;
  bool isObj; 
  lclTypeSpecNode type;
  sort sort;
} *varNode; 

extern varNode varNode_copy (varNode p_x);
extern void varNode_free (/*@only@*/ /*@null@*/ varNode p_x);

# else
# error "Multiple include"
# endif
