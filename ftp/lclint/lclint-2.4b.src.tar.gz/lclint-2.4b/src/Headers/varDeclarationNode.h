/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/

# ifndef VARDECLNODE_H
# define VARDECLNODE_H

typedef struct _varDeclarationNode {
  bool isSpecial;
  /*@reldef@*/ sRef sref;
  bool isGlobal; /* global or varDeclaration */
  bool isPrivate; /* static variable, within a function defn */
  qualifierKind qualifier; /* QLF_NONE, QLF_CONST, or QLF_VOLATILE */
  lclTypeSpecNode type;
  initDeclNodeList decls;
} *varDeclarationNode;

extern void varDeclarationNode_free (/*@only@*/ /*@null@*/ varDeclarationNode p_x);
extern /*@unused@*/ /*@only@*/ cstring 
  varDeclarationNode_unparse (/*@null@*/ varDeclarationNode p_x) /*@*/;

# else
# error "Multiple include"
# endif

