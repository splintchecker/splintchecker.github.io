/* herald.h - created automatically by gmake homeversion */
/*@constant observer char *LCL_VERSION;@*/
# define LCL_VERSION "LCLint 2.4b+ --- Sat Apr 18 21:01:24 EDT 1998"
/*@constant observer char *LCL_PARSE_VERSION;@*/
# define LCL_PARSE_VERSION "LCLint 2.4b+"
/*@constant observer char *LCL_COMPILE;@*/
# define LCL_COMPILE "Compiled using gcc -O5  on Linux salsa 2.0.27 #6 Wed Jan 8 16:31:10 EST 1997 i586 unknown by evs"
