/*@constant observer char *SYSTEM_LIBDIR; @*/
# define SYSTEM_LIBDIR     "/usr/include"

/*@constant observer char *DEFAULT_LARCHPATH; @*/
# define DEFAULT_LARCHPATH ".;/lclint/lclint-2.3j/lib"

/*@constant observer char *DEFAULT_LCLIMPORTDIR; @*/
# define DEFAULT_LCLIMPORTDIR   "/u/evs/lclint/imports"

