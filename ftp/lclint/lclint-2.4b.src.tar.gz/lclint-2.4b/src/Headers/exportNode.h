/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/

typedef enum 
{ 
  XPK_CONST, XPK_VAR, XPK_TYPE, 
  XPK_FCN, XPK_CLAIM, XPK_ITER 
} exportKind;

typedef struct _exportNode {
  exportKind kind;
  union {
    constDeclarationNode constdeclaration;
    varDeclarationNode vardeclaration;
    typeNode type;
    fcnNode fcn;
    claimNode claim;
    iterNode iter;
  } content;
} *exportNode;

extern /*@unused@*/ /*@only@*/ cstring exportNode_unparse (exportNode p_n);

