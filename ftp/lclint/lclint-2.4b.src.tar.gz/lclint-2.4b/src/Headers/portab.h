/*
** Copyright (c) Massachusetts Institute of Technology 1994, 1995, 1996.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. This code may not be re-distributed or modified
**        without permission from MIT (contact 
**        lclint-request@sds.lcs.mit.edu.)  
**
**        Modification and re-distribution are encouraged,
**        but we want to keep track of changes and
**        distribution sites.
*/

# ifndef PORTAB_H
# define PORTAB_H

/*
** Win32 convention?
*/

/*@constant observer char *INCLUDE_VAR@*/
# define INCLUDE_VAR    "include"

#if defined (VMS)
/* Connection string inserted between directory and filename to make a  */
/* full path name.							*/

# define    CONNECTSTR	":"
# define    CONNECTCHAR	':'


/* Directory separator character for search list. */
/*@constant static char SEPCHAR; @*/
# define SEPCHAR ':'

# elif defined(MSDOS) || defined(OS2) || defined(WIN32)

/* Connection string inserted between directory and filename to make a  */
/* full path name.							*/

/*@constant observer char *CONNECTSTR@*/
# define CONNECTSTR	"\\"

/*@constant char CONNECTCHAR@*/
# define CONNECTCHAR	'\\'

# define HASALTCONNECTCHAR

/*@constant char ALTCONNECTCHAR@*/
# define ALTCONNECTCHAR '/'

/* Directory separator character for search list. */

/*@constant char SEPCHAR; @*/
# define SEPCHAR ';'

#else
/* Connection string inserted between directory and filename to make a  */
/* full path name.							*/

/*@constant observer char *CONNECTSTR@*/
# define CONNECTSTR	"/"

/*@constant char CONNECTCHAR; @*/
# define CONNECTCHAR	'/'

/* Directory separator character for search list. */
/*@constant char SEPCHAR; @*/
# define SEPCHAR ':'

#endif


# ifdef P_tmpdir

# if defined(OS2) && defined(__IBMC__)
/*@constant observer char *DEFAULT_TMPDIR; @*/
# define DEFAULT_TMPDIR "."
# else
/*@constant observer char *DEFAULT_TMPDIR; @*/
# define DEFAULT_TMPDIR P_tmpdir
# endif
# else
# ifdef WIN32
/*@constant observer char *DEFAULT_TMPDIR; @*/
# define DEFAULT_TMPDIR "\\WINDOWS\\TEMP\\"
# else
/*@constant observer char *DEFAULT_TMPDIR; @*/
# define DEFAULT_TMPDIR "/tmp/"
# endif /* WIN32 */

# endif /* P_tmpdir */

# else
# error "Multiple include"
# endif
