/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/

typedef enum
{
  LPD_PLAIN, LPD_CHECKS, LPD_REQUIRES, LPD_ENSURES,
  LPD_INTRACLAIM, LPD_CONSTRAINT, LPD_INITIALLY
  } lclPredicateKind;

typedef struct _lclPredicateNode {
  ltoken tok; /* for debugging */
  lclPredicateKind kind;
  struct _termNode *predicate;
} *lclPredicateNode;


