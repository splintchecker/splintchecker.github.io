/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/
# ifndef MESSAGE_H
# define MESSAGE_H

# if USEVARARGS
/*@-usevarargs@*/ /* suppress error about varargs.h */
# include <varargs.h>
/*@=usevarargs@*/
extern cstring message ();
# else
# include <stdarg.h>
/*@messagelike@*/
extern /*@only@*/ cstring message(/*@temp@*/ char *p_fmt, ...) /*@*/ ;
# endif

# else
# error "Multiple include"
# endif
