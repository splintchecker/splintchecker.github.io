/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/
/*
** lslparse.h
*/

extern /*@dependent@*/ /*@null@*/ lslOp g_importedlslOp;
extern bool g_lslParsingTraits;

/*@-namechecks@*/
extern int lsldebug; /* defined by bison (not a bool) */
/*@=namechecks@*/

extern lsymbol processTraitSortId (lsymbol p_sortid); 
extern int parseSignatures (cstring p_infile);
extern /*@only@*/ lslOp parseOpLine (char *p_fname, char *p_line);
extern void readlsignatures (interfaceNode p_n);
extern void callLSL (char *p_specfile, /*@only@*/ char *p_text);
