/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/
/* 
** lclscan.h
*/

# ifndef LCLSCAN_H
# define LCLSCAN_H

extern ltokenCode yllex (void) /*@modifies internalState@*/ ;

extern bool g_inTypeDef;

extern /*@dependent@*/ /*@exposed@*/ ltoken LCLScanNextToken(void) 
   /*@modifies internalState@*/ ;
extern void LCLScanFreshToken(/*@only@*/ ltoken p_tok) 
   /*@modifies internalState@*/ ;

extern /*@exposed@*/ tsource *LCLScanSource(void) /*@*/ ;
extern void LCLScanInit(void) /*@modifies internalState@*/ ;
extern void LCLScanReset(tsource *p_s) /*@modifies internalState@*/ ;
extern void LCLScanCleanup(void) /*@modifies internalState@*/ ;

# else
# error "Multiple include"
# endif


