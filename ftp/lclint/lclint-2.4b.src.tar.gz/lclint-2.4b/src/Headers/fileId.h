/*
** Copyright (c) Massachusetts Institute of Technology 1994-1998.
**          All Rights Reserved.
**          Unpublished rights reserved under the copyright laws of
**          the United States.
**
** THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
** OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
**
** This code is distributed freely and may be used freely under the 
** following conditions:
**
**     1. This notice may not be removed or altered.
**
**     2. Works derived from this code are not distributed for
**        commercial gain without explicit permission from MIT 
**        (for permission contact lclint-request@sds.lcs.mit.edu).
*/
/*
** fileId.h
*/

# ifndef fileId_H
# define fileId_H

immut_typedef int fileId;

/*@constant fileId fileId_invalid; @*/
# define fileId_invalid -1

extern bool fileId_isValid (fileId) /*@*/ ;
# define fileId_isValid(f) ((f) > fileId_invalid)

extern bool fileId_isInvalid (fileId) /*@*/ ;
# define fileId_isInvalid(f) ((f) == fileId_invalid)

extern bool fileId_equal (fileId p_t1, fileId p_t2) /*@*/ ;
# define fileId_equal(t1,t2) ((t1) == (t2))

/* fileId_baseEqual moved to fileTable.h */

extern /*@unused@*/ int 
  fileId_compare (/*@sef@*/ fileId p_t1, /*@sef@*/ fileId p_t2) /*@*/ ;
# define fileId_compare(t1,t2) (int_compare (t1, t2))

# else
# error "Multiple include"
# endif
