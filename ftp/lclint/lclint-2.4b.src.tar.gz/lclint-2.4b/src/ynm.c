/*
** ynm.c
*/

# include "lclintMacros.nf"
# include "basic.h"

ynm ynm_fromCodeChar (char c)
{
  switch (c)
    {
    case '+': return YES;
    case '-': return NO;
    case '=': return MAYBE;
    BADDEFAULT;
    }
}

int ynm_compare (ynm x, ynm y)
{
  switch (x)
    {
    case YES: if (y == YES) return 0; else return 1;
    case NO:  if (y == NO)  return 0; else return -1;
    case MAYBE: if (y == MAYBE) return 0; else return 1;
    }

  BADEXIT;
}
      
      
