typedef /*@abstract@*/ struct
{
  char *name;
  int *id;
} *employee;
