int glob1, glob2;

int f (void) /*@globals glob1;@*/
{    
   return glob2; 
}
