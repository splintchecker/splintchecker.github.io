# include "mstring.h"
# include "bool.h"

extern bool isPalindrome (mstring s);
