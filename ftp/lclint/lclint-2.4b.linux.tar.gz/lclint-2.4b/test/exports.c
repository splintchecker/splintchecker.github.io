# include "exports.h"

int glob;

int f(int a, int b)
{
  return (a + b);
}
